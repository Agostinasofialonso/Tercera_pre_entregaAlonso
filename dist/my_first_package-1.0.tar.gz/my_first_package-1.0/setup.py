from setuptools import setup

setup(
    name="my_first_package",
    version="1.0",
    description="A program that allows modeling of Customers on a shopping website.",
    author="Agostina Alonso",
    author_email="agostialonso1999@gmail.com",
    packages=["my_first_package"],
)